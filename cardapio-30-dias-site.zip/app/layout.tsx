import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "30 Dias Sem Repetir o Almoço",
  description: "30 almoços práticos, econômicos e cheios de sabor por apenas R$ 14,90.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
